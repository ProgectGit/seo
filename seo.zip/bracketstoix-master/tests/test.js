/*jslint vars: true, plusplus: true, continue: true, devel: true, white: true, regexp: true, bitwise: true, nomen: true, indent: 4, maxerr: 50 */

// -------------------------------------------------------------------
//                               How to tidy up your code
//                                  using BracketstoIX
// -------------------------------------------------------------------
function foo() {
  var this_is_line_with_extra_spaces = true;
}