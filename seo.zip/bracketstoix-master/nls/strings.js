'use strict';
// ------------------------------------------------------------------------
// Copyright (c) 2016-2024 Alexandre Bento Freire. All rights reserved.
// Licensed under the MIT License
// ------------------------------------------------------------------------

define(function (require, exports, module) {
  module.exports = {
    root: true,
    "pt": true,
    "de": true,
    "zh-tw": true,
    "zh": true
  };
});
